Hi! Thank you for downloading this free resource.
It's created by Mockups For Free - https://mockupsforfree.com
This mock-up template is free for commercial use, No attribution needed, but appreciated :)
__________________________________________

You Can

- Use  freebie resources for any personal and commercial projects
- Modify resources according to your needs.

You are allowed to use freebie resources for any personal and commercial projects for yourself or for the client, including websites, applications, printed materials and much more. You may modify resources according to your needs. No attribution or link to this site is required, but any credit will be highly appreciated. 
If you wish use the resources in website templates or themes for sale attribution is required by linking back to the specific download page of the resource or to MockupsForFree.com.

_________________________________________

You Cannot

You do not have the right to resell, sublicense or redistribute (even for free) files yourself or as a separate application from any of your work.
If you have any questions about the License, feel free to Contact us for clarification.
